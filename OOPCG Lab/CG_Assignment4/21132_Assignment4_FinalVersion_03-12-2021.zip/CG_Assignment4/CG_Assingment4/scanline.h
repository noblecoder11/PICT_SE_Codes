#ifndef SCANLINE_H
#define SCANLINE_H


class scanline
{
public:
    scanline();
};

#endif // SCANLINE_H
