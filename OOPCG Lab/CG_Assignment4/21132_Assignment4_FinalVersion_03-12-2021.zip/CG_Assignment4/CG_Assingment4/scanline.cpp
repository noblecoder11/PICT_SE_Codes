#include "scanline.h"

scanline::scanline()
{

}
